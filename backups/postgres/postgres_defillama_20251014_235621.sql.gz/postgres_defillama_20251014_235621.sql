--
-- PostgreSQL database dump
--

\restrict FrDDK1lS0DoI2Lgbv0gOYU7JF9Zftb1mZOTCQAV3mhd9xh80qkybjKt8VDLbwsn

-- Dumped from database version 15.14
-- Dumped by pg_dump version 15.14

-- Started on 2025-10-14 16:56:21 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 8 (class 2615 OID 16635)
-- Name: auth; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA auth;


--
-- TOC entry 7 (class 2615 OID 16568)
-- Name: storage; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA storage;


--
-- TOC entry 3 (class 3079 OID 16396)
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA public;


--
-- TOC entry 4000 (class 0 OID 0)
-- Dependencies: 3
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


--
-- TOC entry 2 (class 3079 OID 16385)
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- TOC entry 4001 (class 0 OID 0)
-- Dependencies: 2
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- TOC entry 992 (class 1247 OID 16758)
-- Name: aal_level; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.aal_level AS ENUM (
    'aal1',
    'aal2',
    'aal3'
);


--
-- TOC entry 1016 (class 1247 OID 16899)
-- Name: code_challenge_method; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.code_challenge_method AS ENUM (
    's256',
    'plain'
);


--
-- TOC entry 989 (class 1247 OID 16752)
-- Name: factor_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.factor_status AS ENUM (
    'unverified',
    'verified'
);


--
-- TOC entry 986 (class 1247 OID 16746)
-- Name: factor_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.factor_type AS ENUM (
    'totp',
    'webauthn'
);


--
-- TOC entry 1022 (class 1247 OID 16941)
-- Name: one_time_token_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.one_time_token_type AS ENUM (
    'confirmation_token',
    'reauthentication_token',
    'recovery_token',
    'email_change_token_new',
    'email_change_token_current',
    'phone_change_token'
);


--
-- TOC entry 280 (class 1255 OID 16721)
-- Name: email(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.email() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.email', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'email')
  )::text
$$;


--
-- TOC entry 4002 (class 0 OID 0)
-- Dependencies: 280
-- Name: FUNCTION email(); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth.email() IS 'Deprecated. Use auth.jwt() -> ''email'' instead.';


--
-- TOC entry 281 (class 1255 OID 16728)
-- Name: jwt(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.jwt() RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select 
    coalesce(
        nullif(current_setting('request.jwt.claim', true), ''),
        nullif(current_setting('request.jwt.claims', true), '')
    )::jsonb
$$;


--
-- TOC entry 279 (class 1255 OID 16680)
-- Name: role(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.role() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.role', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'role')
  )::text
$$;


--
-- TOC entry 4003 (class 0 OID 0)
-- Dependencies: 279
-- Name: FUNCTION role(); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth.role() IS 'Deprecated. Use auth.jwt() -> ''role'' instead.';


--
-- TOC entry 278 (class 1255 OID 16679)
-- Name: uid(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.uid() RETURNS uuid
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.sub', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'sub')
  )::uuid
$$;


--
-- TOC entry 4004 (class 0 OID 0)
-- Dependencies: 278
-- Name: FUNCTION uid(); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth.uid() IS 'Deprecated. Use auth.jwt() -> ''sub'' instead.';


--
-- TOC entry 282 (class 1255 OID 17056)
-- Name: update_alert_rules_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_alert_rules_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;


--
-- TOC entry 299 (class 1255 OID 16633)
-- Name: can_insert_object(text, text, uuid, jsonb); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.can_insert_object(bucketid text, name text, owner uuid, metadata jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
  INSERT INTO "storage"."objects" ("bucket_id", "name", "owner", "metadata") VALUES (bucketid, name, owner, metadata);
  -- hack to rollback the successful insert
  RAISE sqlstate 'PT200' using
  message = 'ROLLBACK',
  detail = 'rollback successful insert';
END
$$;


--
-- TOC entry 276 (class 1255 OID 16607)
-- Name: extension(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.extension(name text) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
_parts text[];
_filename text;
BEGIN
	select string_to_array(name, '/') into _parts;
	select _parts[array_length(_parts,1)] into _filename;
	-- @todo return the last part instead of 2
	return reverse(split_part(reverse(_filename), '.', 1));
END
$$;


--
-- TOC entry 275 (class 1255 OID 16606)
-- Name: filename(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.filename(name text) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
_parts text[];
BEGIN
	select string_to_array(name, '/') into _parts;
	return _parts[array_length(_parts,1)];
END
$$;


--
-- TOC entry 274 (class 1255 OID 16605)
-- Name: foldername(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.foldername(name text) RETURNS text[]
    LANGUAGE plpgsql
    AS $$
DECLARE
_parts text[];
BEGIN
	select string_to_array(name, '/') into _parts;
	return _parts[1:array_length(_parts,1)-1];
END
$$;


--
-- TOC entry 277 (class 1255 OID 16619)
-- Name: get_size_by_bucket(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.get_size_by_bucket() RETURNS TABLE(size bigint, bucket_id text)
    LANGUAGE plpgsql
    AS $$
BEGIN
    return query
        select sum((metadata->>'size')::int) as size, obj.bucket_id
        from "storage".objects as obj
        group by obj.bucket_id;
END
$$;


--
-- TOC entry 297 (class 1255 OID 16622)
-- Name: search(text, text, integer, integer, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.search(prefix text, bucketname text, limits integer DEFAULT 100, levels integer DEFAULT 1, offsets integer DEFAULT 0, search text DEFAULT ''::text, sortcolumn text DEFAULT 'name'::text, sortorder text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
declare
  v_order_by text;
  v_sort_order text;
begin
  case
    when sortcolumn = 'name' then
      v_order_by = 'name';
    when sortcolumn = 'updated_at' then
      v_order_by = 'updated_at';
    when sortcolumn = 'created_at' then
      v_order_by = 'created_at';
    when sortcolumn = 'last_accessed_at' then
      v_order_by = 'last_accessed_at';
    else
      v_order_by = 'name';
  end case;

  case
    when sortorder = 'asc' then
      v_sort_order = 'asc';
    when sortorder = 'desc' then
      v_sort_order = 'desc';
    else
      v_sort_order = 'asc';
  end case;

  v_order_by = v_order_by || ' ' || v_sort_order;

  return query execute
    'with folders as (
       select path_tokens[$1] as folder
       from storage.objects
         where objects.name ilike $2 || $3 || ''%''
           and bucket_id = $4
           and array_length(regexp_split_to_array(objects.name, ''/''), 1) <> $1
       group by folder
       order by folder ' || v_sort_order || '
     )
     (select folder as "name",
            null as id,
            null as updated_at,
            null as created_at,
            null as last_accessed_at,
            null as metadata from folders)
     union all
     (select path_tokens[$1] as "name",
            id,
            updated_at,
            created_at,
            last_accessed_at,
            metadata
     from storage.objects
     where objects.name ilike $2 || $3 || ''%''
       and bucket_id = $4
       and array_length(regexp_split_to_array(objects.name, ''/''), 1) = $1
     order by ' || v_order_by || ')
     limit $5
     offset $6' using levels, prefix, search, bucketname, limits, offsets;
end;
$_$;


--
-- TOC entry 298 (class 1255 OID 16623)
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW; 
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 240 (class 1259 OID 16666)
-- Name: audit_log_entries; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.audit_log_entries (
    instance_id uuid,
    id uuid NOT NULL,
    payload json,
    created_at timestamp with time zone,
    ip_address character varying(64) DEFAULT ''::character varying NOT NULL
);


--
-- TOC entry 4005 (class 0 OID 0)
-- Dependencies: 240
-- Name: TABLE audit_log_entries; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.audit_log_entries IS 'Auth: Audit trail for user actions.';


--
-- TOC entry 251 (class 1259 OID 16903)
-- Name: flow_state; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.flow_state (
    id uuid NOT NULL,
    user_id uuid,
    auth_code text NOT NULL,
    code_challenge_method public.code_challenge_method NOT NULL,
    code_challenge text NOT NULL,
    provider_type text NOT NULL,
    provider_access_token text,
    provider_refresh_token text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    authentication_method text NOT NULL,
    auth_code_issued_at timestamp with time zone
);


--
-- TOC entry 4006 (class 0 OID 0)
-- Dependencies: 251
-- Name: TABLE flow_state; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.flow_state IS 'stores metadata for pkce logins';


--
-- TOC entry 242 (class 1259 OID 16700)
-- Name: identities; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.identities (
    provider_id text NOT NULL,
    user_id uuid NOT NULL,
    identity_data jsonb NOT NULL,
    provider text NOT NULL,
    last_sign_in_at timestamp with time zone,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    email text GENERATED ALWAYS AS (lower((identity_data ->> 'email'::text))) STORED,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


--
-- TOC entry 4007 (class 0 OID 0)
-- Dependencies: 242
-- Name: TABLE identities; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.identities IS 'Auth: Stores identities associated to a user.';


--
-- TOC entry 4008 (class 0 OID 0)
-- Dependencies: 242
-- Name: COLUMN identities.email; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.identities.email IS 'Auth: Email is a generated column that references the optional email property in the identity_data';


--
-- TOC entry 239 (class 1259 OID 16659)
-- Name: instances; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.instances (
    id uuid NOT NULL,
    uuid uuid,
    raw_base_config text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


--
-- TOC entry 4009 (class 0 OID 0)
-- Dependencies: 239
-- Name: TABLE instances; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.instances IS 'Auth: Manages users across multiple sites.';


--
-- TOC entry 246 (class 1259 OID 16790)
-- Name: mfa_amr_claims; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.mfa_amr_claims (
    session_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    authentication_method text NOT NULL,
    id uuid NOT NULL
);


--
-- TOC entry 4010 (class 0 OID 0)
-- Dependencies: 246
-- Name: TABLE mfa_amr_claims; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.mfa_amr_claims IS 'auth: stores authenticator method reference claims for multi factor authentication';


--
-- TOC entry 245 (class 1259 OID 16778)
-- Name: mfa_challenges; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.mfa_challenges (
    id uuid NOT NULL,
    factor_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    verified_at timestamp with time zone,
    ip_address inet NOT NULL
);


--
-- TOC entry 4011 (class 0 OID 0)
-- Dependencies: 245
-- Name: TABLE mfa_challenges; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.mfa_challenges IS 'auth: stores metadata about challenge requests made';


--
-- TOC entry 244 (class 1259 OID 16765)
-- Name: mfa_factors; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.mfa_factors (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    friendly_name text,
    factor_type public.factor_type NOT NULL,
    status public.factor_status NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    secret text
);


--
-- TOC entry 4012 (class 0 OID 0)
-- Dependencies: 244
-- Name: TABLE mfa_factors; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.mfa_factors IS 'auth: stores metadata about factors';


--
-- TOC entry 252 (class 1259 OID 16953)
-- Name: one_time_tokens; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.one_time_tokens (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    token_type public.one_time_token_type NOT NULL,
    token_hash text NOT NULL,
    relates_to text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT one_time_tokens_token_hash_check CHECK ((char_length(token_hash) > 0))
);


--
-- TOC entry 238 (class 1259 OID 16648)
-- Name: refresh_tokens; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.refresh_tokens (
    instance_id uuid,
    id bigint NOT NULL,
    token character varying(255),
    user_id character varying(255),
    revoked boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    parent character varying(255),
    session_id uuid
);


--
-- TOC entry 4013 (class 0 OID 0)
-- Dependencies: 238
-- Name: TABLE refresh_tokens; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.refresh_tokens IS 'Auth: Store of tokens used to refresh JWT tokens once they expire.';


--
-- TOC entry 237 (class 1259 OID 16647)
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: auth; Owner: -
--

CREATE SEQUENCE auth.refresh_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 4014 (class 0 OID 0)
-- Dependencies: 237
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: auth; Owner: -
--

ALTER SEQUENCE auth.refresh_tokens_id_seq OWNED BY auth.refresh_tokens.id;


--
-- TOC entry 249 (class 1259 OID 16832)
-- Name: saml_providers; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.saml_providers (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    entity_id text NOT NULL,
    metadata_xml text NOT NULL,
    metadata_url text,
    attribute_mapping jsonb,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    name_id_format text,
    CONSTRAINT "entity_id not empty" CHECK ((char_length(entity_id) > 0)),
    CONSTRAINT "metadata_url not empty" CHECK (((metadata_url = NULL::text) OR (char_length(metadata_url) > 0))),
    CONSTRAINT "metadata_xml not empty" CHECK ((char_length(metadata_xml) > 0))
);


--
-- TOC entry 4015 (class 0 OID 0)
-- Dependencies: 249
-- Name: TABLE saml_providers; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.saml_providers IS 'Auth: Manages SAML Identity Provider connections.';


--
-- TOC entry 250 (class 1259 OID 16850)
-- Name: saml_relay_states; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.saml_relay_states (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    request_id text NOT NULL,
    for_email text,
    redirect_to text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    flow_state_id uuid,
    CONSTRAINT "request_id not empty" CHECK ((char_length(request_id) > 0))
);


--
-- TOC entry 4016 (class 0 OID 0)
-- Dependencies: 250
-- Name: TABLE saml_relay_states; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.saml_relay_states IS 'Auth: Contains SAML Relay State information for each Service Provider initiated login.';


--
-- TOC entry 241 (class 1259 OID 16674)
-- Name: schema_migrations; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.schema_migrations (
    version character varying(255) NOT NULL
);


--
-- TOC entry 4017 (class 0 OID 0)
-- Dependencies: 241
-- Name: TABLE schema_migrations; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.schema_migrations IS 'Auth: Manages updates to the auth system.';


--
-- TOC entry 243 (class 1259 OID 16730)
-- Name: sessions; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.sessions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    factor_id uuid,
    aal public.aal_level,
    not_after timestamp with time zone,
    refreshed_at timestamp without time zone,
    user_agent text,
    ip inet,
    tag text
);


--
-- TOC entry 4018 (class 0 OID 0)
-- Dependencies: 243
-- Name: TABLE sessions; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.sessions IS 'Auth: Stores session data associated to a user.';


--
-- TOC entry 4019 (class 0 OID 0)
-- Dependencies: 243
-- Name: COLUMN sessions.not_after; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.sessions.not_after IS 'Auth: Not after is a nullable column that contains a timestamp after which the session should be regarded as expired.';


--
-- TOC entry 248 (class 1259 OID 16817)
-- Name: sso_domains; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.sso_domains (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    domain text NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    CONSTRAINT "domain not empty" CHECK ((char_length(domain) > 0))
);


--
-- TOC entry 4020 (class 0 OID 0)
-- Dependencies: 248
-- Name: TABLE sso_domains; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.sso_domains IS 'Auth: Manages SSO email address domain mapping to an SSO Identity Provider.';


--
-- TOC entry 247 (class 1259 OID 16808)
-- Name: sso_providers; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.sso_providers (
    id uuid NOT NULL,
    resource_id text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    CONSTRAINT "resource_id not empty" CHECK (((resource_id = NULL::text) OR (char_length(resource_id) > 0)))
);


--
-- TOC entry 4021 (class 0 OID 0)
-- Dependencies: 247
-- Name: TABLE sso_providers; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.sso_providers IS 'Auth: Manages SSO identity provider information; see saml_providers for SAML.';


--
-- TOC entry 4022 (class 0 OID 0)
-- Dependencies: 247
-- Name: COLUMN sso_providers.resource_id; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.sso_providers.resource_id IS 'Auth: Uniquely identifies a SSO provider according to a user-chosen resource ID (case insensitive), useful in infrastructure as code.';


--
-- TOC entry 236 (class 1259 OID 16636)
-- Name: users; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.users (
    instance_id uuid,
    id uuid NOT NULL,
    aud character varying(255),
    role character varying(255),
    email character varying(255),
    encrypted_password character varying(255),
    email_confirmed_at timestamp with time zone,
    invited_at timestamp with time zone,
    confirmation_token character varying(255),
    confirmation_sent_at timestamp with time zone,
    recovery_token character varying(255),
    recovery_sent_at timestamp with time zone,
    email_change_token_new character varying(255),
    email_change character varying(255),
    email_change_sent_at timestamp with time zone,
    last_sign_in_at timestamp with time zone,
    raw_app_meta_data jsonb,
    raw_user_meta_data jsonb,
    is_super_admin boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    phone text DEFAULT NULL::character varying,
    phone_confirmed_at timestamp with time zone,
    phone_change text DEFAULT ''::character varying,
    phone_change_token character varying(255) DEFAULT ''::character varying,
    phone_change_sent_at timestamp with time zone,
    confirmed_at timestamp with time zone GENERATED ALWAYS AS (LEAST(email_confirmed_at, phone_confirmed_at)) STORED,
    email_change_token_current character varying(255) DEFAULT ''::character varying,
    email_change_confirm_status smallint DEFAULT 0,
    banned_until timestamp with time zone,
    reauthentication_token character varying(255) DEFAULT ''::character varying,
    reauthentication_sent_at timestamp with time zone,
    is_sso_user boolean DEFAULT false NOT NULL,
    deleted_at timestamp with time zone,
    is_anonymous boolean DEFAULT false NOT NULL,
    CONSTRAINT users_email_change_confirm_status_check CHECK (((email_change_confirm_status >= 0) AND (email_change_confirm_status <= 2)))
);


--
-- TOC entry 4023 (class 0 OID 0)
-- Dependencies: 236
-- Name: TABLE users; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.users IS 'Auth: Stores user login data within a secure schema.';


--
-- TOC entry 4024 (class 0 OID 0)
-- Dependencies: 236
-- Name: COLUMN users.is_sso_user; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.users.is_sso_user IS 'Auth: Set this column to true when the account comes from SSO. These accounts can have duplicate emails.';


--
-- TOC entry 227 (class 1259 OID 16502)
-- Name: api_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.api_keys (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    key text NOT NULL,
    user_id uuid,
    name text,
    permissions jsonb DEFAULT '{}'::jsonb,
    rate_limit integer DEFAULT 1000,
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    expires_at timestamp with time zone
);


--
-- TOC entry 228 (class 1259 OID 16516)
-- Name: websocket_connections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.websocket_connections (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    connection_id text NOT NULL,
    user_id uuid,
    api_key_id uuid,
    connected_at timestamp with time zone DEFAULT now(),
    last_heartbeat timestamp with time zone DEFAULT now(),
    subscriptions jsonb DEFAULT '[]'::jsonb,
    metadata jsonb DEFAULT '{}'::jsonb
);


--
-- TOC entry 229 (class 1259 OID 16544)
-- Name: active_connections; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.active_connections AS
 SELECT wc.id,
    wc.connection_id,
    wc.user_id,
    wc.api_key_id,
    wc.connected_at,
    wc.last_heartbeat,
    wc.subscriptions,
    wc.metadata,
    ak.name AS api_key_name,
    ak.rate_limit
   FROM (public.websocket_connections wc
     LEFT JOIN public.api_keys ak ON ((wc.api_key_id = ak.id)))
  WHERE (wc.last_heartbeat > (now() - '00:05:00'::interval));


--
-- TOC entry 256 (class 1259 OID 17031)
-- Name: alert_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alert_history (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    alert_rule_id uuid NOT NULL,
    user_id character varying(255) NOT NULL,
    triggered_value numeric(20,8) NOT NULL,
    threshold_value numeric(20,8) NOT NULL,
    message text NOT NULL,
    notification_channels text[] NOT NULL,
    delivery_status jsonb,
    created_at timestamp with time zone DEFAULT now(),
    error_details jsonb
);


--
-- TOC entry 4025 (class 0 OID 0)
-- Dependencies: 256
-- Name: TABLE alert_history; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.alert_history IS 'Historical record of triggered alerts for audit and throttling purposes';


--
-- TOC entry 4026 (class 0 OID 0)
-- Dependencies: 256
-- Name: COLUMN alert_history.delivery_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.alert_history.delivery_status IS 'JSONB object tracking delivery status per channel';


--
-- TOC entry 4027 (class 0 OID 0)
-- Dependencies: 256
-- Name: COLUMN alert_history.error_details; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.alert_history.error_details IS 'Error details for failed notification deliveries';


--
-- TOC entry 255 (class 1259 OID 17015)
-- Name: alert_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alert_rules (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    alert_type character varying(50) NOT NULL,
    protocol_id text,
    token_id text,
    chain_id integer,
    condition jsonb NOT NULL,
    channels jsonb DEFAULT '[]'::jsonb NOT NULL,
    throttle_minutes integer DEFAULT 5,
    enabled boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    last_triggered_at timestamp with time zone,
    webhook_url character varying(500),
    CONSTRAINT alert_rules_alert_type_check CHECK (((alert_type)::text = ANY ((ARRAY['tvl_change'::character varying, 'price_change'::character varying, 'volume_spike'::character varying, 'protocol_event'::character varying, 'smart_money'::character varying, 'risk_score'::character varying])::text[]))),
    CONSTRAINT alert_rules_throttle_minutes_check CHECK ((throttle_minutes >= 0)),
    CONSTRAINT alert_target_check CHECK (((protocol_id IS NOT NULL) OR (token_id IS NOT NULL) OR (chain_id IS NOT NULL)))
);


--
-- TOC entry 4028 (class 0 OID 0)
-- Dependencies: 255
-- Name: TABLE alert_rules; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.alert_rules IS 'User-defined alert rules for monitoring DeFi protocols, tokens, and chains';


--
-- TOC entry 4029 (class 0 OID 0)
-- Dependencies: 255
-- Name: COLUMN alert_rules.condition; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.alert_rules.condition IS 'JSONB field containing flexible condition configuration with operators, thresholds, and metrics';


--
-- TOC entry 4030 (class 0 OID 0)
-- Dependencies: 255
-- Name: COLUMN alert_rules.channels; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.alert_rules.channels IS 'JSONB array of notification channels: email, webhook, push';


--
-- TOC entry 4031 (class 0 OID 0)
-- Dependencies: 255
-- Name: COLUMN alert_rules.throttle_minutes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.alert_rules.throttle_minutes IS 'Minimum minutes between alert notifications to prevent spam';


--
-- TOC entry 4032 (class 0 OID 0)
-- Dependencies: 255
-- Name: COLUMN alert_rules.webhook_url; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.alert_rules.webhook_url IS 'Webhook URL for webhook notifications';


--
-- TOC entry 223 (class 1259 OID 16457)
-- Name: alerts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alerts (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    type text NOT NULL,
    message text NOT NULL,
    priority text DEFAULT 'medium'::text,
    protocol_id text,
    token_id text,
    read boolean DEFAULT false,
    "timestamp" timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 225 (class 1259 OID 16479)
-- Name: governance_proposals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.governance_proposals (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    protocol_id text NOT NULL,
    proposal_id text NOT NULL,
    title text NOT NULL,
    description text,
    status text DEFAULT 'active'::text,
    votes_for numeric(20,2) DEFAULT 0,
    votes_against numeric(20,2) DEFAULT 0,
    end_time timestamp with time zone,
    "timestamp" timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 220 (class 1259 OID 16427)
-- Name: price_updates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.price_updates (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    token_id text NOT NULL,
    price numeric(20,8) NOT NULL,
    change_24h numeric(10,4),
    volume_24h numeric(20,2),
    market_cap numeric(20,2),
    "timestamp" timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 230 (class 1259 OID 16549)
-- Name: latest_prices; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.latest_prices AS
 SELECT DISTINCT ON (price_updates.token_id) price_updates.token_id,
    price_updates.price,
    price_updates.change_24h,
    price_updates.volume_24h,
    price_updates.market_cap,
    price_updates."timestamp"
   FROM public.price_updates
  ORDER BY price_updates.token_id, price_updates."timestamp" DESC;


--
-- TOC entry 224 (class 1259 OID 16469)
-- Name: liquidations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.liquidations (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    protocol_id text NOT NULL,
    user_address text NOT NULL,
    collateral_token text,
    debt_token text,
    collateral_amount numeric(20,8),
    debt_amount numeric(20,8),
    liquidation_price numeric(20,8),
    "timestamp" timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 257 (class 1259 OID 17058)
-- Name: notification_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    alert_history_id uuid NOT NULL,
    channel character varying(20) NOT NULL,
    status character varying(20) NOT NULL,
    recipient character varying(500),
    error_message text,
    retry_count integer DEFAULT 0,
    sent_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    CONSTRAINT notification_logs_status_check CHECK (((status)::text = ANY ((ARRAY['sent'::character varying, 'failed'::character varying, 'pending'::character varying])::text[])))
);


--
-- TOC entry 4033 (class 0 OID 0)
-- Dependencies: 257
-- Name: TABLE notification_logs; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.notification_logs IS 'Detailed logs for notification deliveries';


--
-- TOC entry 4034 (class 0 OID 0)
-- Dependencies: 257
-- Name: COLUMN notification_logs.alert_history_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.notification_logs.alert_history_id IS 'Reference to alert_history';


--
-- TOC entry 4035 (class 0 OID 0)
-- Dependencies: 257
-- Name: COLUMN notification_logs.channel; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.notification_logs.channel IS 'Notification channel (email, webhook, push)';


--
-- TOC entry 4036 (class 0 OID 0)
-- Dependencies: 257
-- Name: COLUMN notification_logs.status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.notification_logs.status IS 'Delivery status';


--
-- TOC entry 4037 (class 0 OID 0)
-- Dependencies: 257
-- Name: COLUMN notification_logs.recipient; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.notification_logs.recipient IS 'Recipient (email address, webhook URL, device token)';


--
-- TOC entry 4038 (class 0 OID 0)
-- Dependencies: 257
-- Name: COLUMN notification_logs.error_message; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.notification_logs.error_message IS 'Error message if failed';


--
-- TOC entry 4039 (class 0 OID 0)
-- Dependencies: 257
-- Name: COLUMN notification_logs.retry_count; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.notification_logs.retry_count IS 'Number of retry attempts';


--
-- TOC entry 4040 (class 0 OID 0)
-- Dependencies: 257
-- Name: COLUMN notification_logs.sent_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.notification_logs.sent_at IS 'Timestamp when notification was sent';


--
-- TOC entry 254 (class 1259 OID 16989)
-- Name: notification_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_templates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    alert_type character varying(50) NOT NULL,
    channel character varying(20) NOT NULL,
    subject_template text,
    body_template text NOT NULL,
    variables jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    CONSTRAINT notification_templates_channel_check CHECK (((channel)::text = ANY ((ARRAY['email'::character varying, 'webhook'::character varying, 'push'::character varying])::text[])))
);


--
-- TOC entry 4041 (class 0 OID 0)
-- Dependencies: 254
-- Name: TABLE notification_templates; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.notification_templates IS 'Notification templates for different alert types and channels';


--
-- TOC entry 4042 (class 0 OID 0)
-- Dependencies: 254
-- Name: COLUMN notification_templates.name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.notification_templates.name IS 'Template name';


--
-- TOC entry 4043 (class 0 OID 0)
-- Dependencies: 254
-- Name: COLUMN notification_templates.alert_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.notification_templates.alert_type IS 'Alert type (price_change, tvl_change, etc.)';


--
-- TOC entry 4044 (class 0 OID 0)
-- Dependencies: 254
-- Name: COLUMN notification_templates.channel; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.notification_templates.channel IS 'Notification channel (email, webhook, push)';


--
-- TOC entry 4045 (class 0 OID 0)
-- Dependencies: 254
-- Name: COLUMN notification_templates.subject_template; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.notification_templates.subject_template IS 'Subject template (for email)';


--
-- TOC entry 4046 (class 0 OID 0)
-- Dependencies: 254
-- Name: COLUMN notification_templates.body_template; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.notification_templates.body_template IS 'Body template with variables';


--
-- TOC entry 4047 (class 0 OID 0)
-- Dependencies: 254
-- Name: COLUMN notification_templates.variables; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.notification_templates.variables IS 'Available variables for template';


--
-- TOC entry 261 (class 1259 OID 17119)
-- Name: protocol_stats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.protocol_stats (
    id text NOT NULL,
    protocol_id text NOT NULL,
    total_tvl numeric NOT NULL,
    total_chains integer NOT NULL,
    avg_tvl_per_chain numeric,
    max_tvl numeric,
    min_tvl numeric,
    last_updated timestamp without time zone NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


--
-- TOC entry 4048 (class 0 OID 0)
-- Dependencies: 261
-- Name: TABLE protocol_stats; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.protocol_stats IS 'Aggregated statistics for protocols';


--
-- TOC entry 259 (class 1259 OID 17088)
-- Name: protocol_tvl; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.protocol_tvl (
    id text NOT NULL,
    protocol_id text NOT NULL,
    chain text NOT NULL,
    tvl numeric NOT NULL,
    tvl_prev_day numeric,
    tvl_prev_week numeric,
    tvl_prev_month numeric,
    change_1d numeric,
    change_7d numeric,
    change_30d numeric,
    "timestamp" timestamp without time zone NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


--
-- TOC entry 4049 (class 0 OID 0)
-- Dependencies: 259
-- Name: TABLE protocol_tvl; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.protocol_tvl IS 'Time-series TVL data for protocols by chain';


--
-- TOC entry 4050 (class 0 OID 0)
-- Dependencies: 259
-- Name: COLUMN protocol_tvl.tvl; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.protocol_tvl.tvl IS 'Total Value Locked in USD';


--
-- TOC entry 4051 (class 0 OID 0)
-- Dependencies: 259
-- Name: COLUMN protocol_tvl.change_1d; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.protocol_tvl.change_1d IS 'Percentage change in last 24 hours';


--
-- TOC entry 222 (class 1259 OID 16447)
-- Name: protocol_updates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.protocol_updates (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    protocol_id text NOT NULL,
    name text NOT NULL,
    category text,
    chains text[],
    tvl numeric(20,2),
    "timestamp" timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 231 (class 1259 OID 16553)
-- Name: protocol_tvl_summary; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.protocol_tvl_summary AS
 SELECT pu1.protocol_id,
    pu1.name,
    pu1.category,
    pu1.chains,
    pu1.tvl,
    pu1."timestamp"
   FROM public.protocol_updates pu1
  WHERE (pu1."timestamp" = ( SELECT max(pu2."timestamp") AS max
           FROM public.protocol_updates pu2
          WHERE (pu2.protocol_id = pu1.protocol_id)));


--
-- TOC entry 258 (class 1259 OID 17077)
-- Name: protocols; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.protocols (
    id text NOT NULL,
    name text NOT NULL,
    category text,
    chains text[],
    description text,
    website text,
    logo_url text,
    twitter text,
    audit_links text[],
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- TOC entry 4052 (class 0 OID 0)
-- Dependencies: 258
-- Name: TABLE protocols; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.protocols IS 'Protocol metadata and information';


--
-- TOC entry 4053 (class 0 OID 0)
-- Dependencies: 258
-- Name: COLUMN protocols.chains; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.protocols.chains IS 'Array of chains where protocol is deployed';


--
-- TOC entry 262 (class 1259 OID 17134)
-- Name: query_cache; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.query_cache (
    cache_key text NOT NULL,
    query_hash text NOT NULL,
    result jsonb NOT NULL,
    hit_count integer DEFAULT 0,
    expires_at timestamp without time zone NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- TOC entry 4054 (class 0 OID 0)
-- Dependencies: 262
-- Name: TABLE query_cache; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.query_cache IS 'Cached query results for performance optimization';


--
-- TOC entry 4055 (class 0 OID 0)
-- Dependencies: 262
-- Name: COLUMN query_cache.expires_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.query_cache.expires_at IS 'Cache expiration timestamp (TTL)';


--
-- TOC entry 263 (class 1259 OID 17146)
-- Name: query_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.query_logs (
    id text NOT NULL,
    user_id text,
    query_hash text NOT NULL,
    query_params jsonb NOT NULL,
    execution_time_ms integer NOT NULL,
    result_count integer,
    cache_hit boolean DEFAULT false,
    error_message text,
    created_at timestamp without time zone DEFAULT now()
);


--
-- TOC entry 4056 (class 0 OID 0)
-- Dependencies: 263
-- Name: TABLE query_logs; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.query_logs IS 'Query execution logs for monitoring and analytics';


--
-- TOC entry 4057 (class 0 OID 0)
-- Dependencies: 263
-- Name: COLUMN query_logs.execution_time_ms; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.query_logs.execution_time_ms IS 'Query execution time in milliseconds';


--
-- TOC entry 232 (class 1259 OID 16562)
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.schema_migrations (
    version character varying(14) NOT NULL
);


--
-- TOC entry 226 (class 1259 OID 16492)
-- Name: token_emissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.token_emissions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    protocol_id text NOT NULL,
    token_id text NOT NULL,
    emission_rate numeric(20,8),
    total_supply numeric(30,8),
    circulating_supply numeric(30,8),
    "timestamp" timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 260 (class 1259 OID 17106)
-- Name: token_prices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.token_prices (
    id text NOT NULL,
    token_id text NOT NULL,
    token_symbol text NOT NULL,
    token_name text,
    price numeric NOT NULL,
    price_prev_day numeric,
    price_prev_week numeric,
    price_prev_month numeric,
    change_1d numeric,
    change_7d numeric,
    change_30d numeric,
    volume_24h numeric,
    market_cap numeric,
    "timestamp" timestamp without time zone NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


--
-- TOC entry 4058 (class 0 OID 0)
-- Dependencies: 260
-- Name: TABLE token_prices; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.token_prices IS 'Time-series price data for tokens';


--
-- TOC entry 4059 (class 0 OID 0)
-- Dependencies: 260
-- Name: COLUMN token_prices.price; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.token_prices.price IS 'Token price in USD';


--
-- TOC entry 4060 (class 0 OID 0)
-- Dependencies: 260
-- Name: COLUMN token_prices.volume_24h; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.token_prices.volume_24h IS '24-hour trading volume in USD';


--
-- TOC entry 221 (class 1259 OID 16437)
-- Name: tvl_updates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tvl_updates (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    protocol_id text NOT NULL,
    tvl numeric(20,2) NOT NULL,
    change_24h numeric(10,4),
    chain text,
    "timestamp" timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 253 (class 1259 OID 16974)
-- Name: user_devices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_devices (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255) NOT NULL,
    device_token character varying(500) NOT NULL,
    platform character varying(20) NOT NULL,
    device_name character varying(255),
    app_version character varying(50),
    os_version character varying(50),
    enabled boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    CONSTRAINT user_devices_platform_check CHECK (((platform)::text = ANY ((ARRAY['ios'::character varying, 'android'::character varying])::text[])))
);


--
-- TOC entry 4061 (class 0 OID 0)
-- Dependencies: 253
-- Name: TABLE user_devices; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.user_devices IS 'User device tokens for push notifications';


--
-- TOC entry 4062 (class 0 OID 0)
-- Dependencies: 253
-- Name: COLUMN user_devices.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.user_devices.id IS 'Unique device identifier';


--
-- TOC entry 4063 (class 0 OID 0)
-- Dependencies: 253
-- Name: COLUMN user_devices.user_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.user_devices.user_id IS 'User identifier';


--
-- TOC entry 4064 (class 0 OID 0)
-- Dependencies: 253
-- Name: COLUMN user_devices.device_token; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.user_devices.device_token IS 'Device token for push notifications (APNS/FCM)';


--
-- TOC entry 4065 (class 0 OID 0)
-- Dependencies: 253
-- Name: COLUMN user_devices.platform; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.user_devices.platform IS 'Device platform: ios or android';


--
-- TOC entry 4066 (class 0 OID 0)
-- Dependencies: 253
-- Name: COLUMN user_devices.device_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.user_devices.device_name IS 'Device name (e.g., iPhone 13 Pro)';


--
-- TOC entry 4067 (class 0 OID 0)
-- Dependencies: 253
-- Name: COLUMN user_devices.app_version; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.user_devices.app_version IS 'App version';


--
-- TOC entry 4068 (class 0 OID 0)
-- Dependencies: 253
-- Name: COLUMN user_devices.os_version; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.user_devices.os_version IS 'OS version';


--
-- TOC entry 4069 (class 0 OID 0)
-- Dependencies: 253
-- Name: COLUMN user_devices.enabled; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.user_devices.enabled IS 'Whether device is enabled for notifications';


--
-- TOC entry 234 (class 1259 OID 16577)
-- Name: buckets; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.buckets (
    id text NOT NULL,
    name text NOT NULL,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    public boolean DEFAULT false,
    avif_autodetection boolean DEFAULT false,
    file_size_limit bigint,
    allowed_mime_types text[],
    owner_id text
);


--
-- TOC entry 4070 (class 0 OID 0)
-- Dependencies: 234
-- Name: COLUMN buckets.owner; Type: COMMENT; Schema: storage; Owner: -
--

COMMENT ON COLUMN storage.buckets.owner IS 'Field is deprecated, use owner_id instead';


--
-- TOC entry 233 (class 1259 OID 16569)
-- Name: migrations; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.migrations (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    hash character varying(40) NOT NULL,
    executed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 235 (class 1259 OID 16587)
-- Name: objects; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.objects (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bucket_id text,
    name text,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    last_accessed_at timestamp with time zone DEFAULT now(),
    metadata jsonb,
    path_tokens text[] GENERATED ALWAYS AS (string_to_array(name, '/'::text)) STORED,
    version text,
    owner_id text
);


--
-- TOC entry 4071 (class 0 OID 0)
-- Dependencies: 235
-- Name: COLUMN objects.owner; Type: COMMENT; Schema: storage; Owner: -
--

COMMENT ON COLUMN storage.objects.owner IS 'Field is deprecated, use owner_id instead';


--
-- TOC entry 3535 (class 2604 OID 16651)
-- Name: refresh_tokens id; Type: DEFAULT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens ALTER COLUMN id SET DEFAULT nextval('auth.refresh_tokens_id_seq'::regclass);


--
-- TOC entry 3971 (class 0 OID 16666)
-- Dependencies: 240
-- Data for Name: audit_log_entries; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.audit_log_entries (instance_id, id, payload, created_at, ip_address) FROM stdin;
\.


--
-- TOC entry 3982 (class 0 OID 16903)
-- Dependencies: 251
-- Data for Name: flow_state; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.flow_state (id, user_id, auth_code, code_challenge_method, code_challenge, provider_type, provider_access_token, provider_refresh_token, created_at, updated_at, authentication_method, auth_code_issued_at) FROM stdin;
\.


--
-- TOC entry 3973 (class 0 OID 16700)
-- Dependencies: 242
-- Data for Name: identities; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.identities (provider_id, user_id, identity_data, provider, last_sign_in_at, created_at, updated_at, id) FROM stdin;
\.


--
-- TOC entry 3970 (class 0 OID 16659)
-- Dependencies: 239
-- Data for Name: instances; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.instances (id, uuid, raw_base_config, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3977 (class 0 OID 16790)
-- Dependencies: 246
-- Data for Name: mfa_amr_claims; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.mfa_amr_claims (session_id, created_at, updated_at, authentication_method, id) FROM stdin;
\.


--
-- TOC entry 3976 (class 0 OID 16778)
-- Dependencies: 245
-- Data for Name: mfa_challenges; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.mfa_challenges (id, factor_id, created_at, verified_at, ip_address) FROM stdin;
\.


--
-- TOC entry 3975 (class 0 OID 16765)
-- Dependencies: 244
-- Data for Name: mfa_factors; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.mfa_factors (id, user_id, friendly_name, factor_type, status, created_at, updated_at, secret) FROM stdin;
\.


--
-- TOC entry 3983 (class 0 OID 16953)
-- Dependencies: 252
-- Data for Name: one_time_tokens; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.one_time_tokens (id, user_id, token_type, token_hash, relates_to, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3969 (class 0 OID 16648)
-- Dependencies: 238
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) FROM stdin;
\.


--
-- TOC entry 3980 (class 0 OID 16832)
-- Dependencies: 249
-- Data for Name: saml_providers; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.saml_providers (id, sso_provider_id, entity_id, metadata_xml, metadata_url, attribute_mapping, created_at, updated_at, name_id_format) FROM stdin;
\.


--
-- TOC entry 3981 (class 0 OID 16850)
-- Dependencies: 250
-- Data for Name: saml_relay_states; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.saml_relay_states (id, sso_provider_id, request_id, for_email, redirect_to, created_at, updated_at, flow_state_id) FROM stdin;
\.


--
-- TOC entry 3972 (class 0 OID 16674)
-- Dependencies: 241
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.schema_migrations (version) FROM stdin;
\.


--
-- TOC entry 3974 (class 0 OID 16730)
-- Dependencies: 243
-- Data for Name: sessions; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.sessions (id, user_id, created_at, updated_at, factor_id, aal, not_after, refreshed_at, user_agent, ip, tag) FROM stdin;
\.


--
-- TOC entry 3979 (class 0 OID 16817)
-- Dependencies: 248
-- Data for Name: sso_domains; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.sso_domains (id, sso_provider_id, domain, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3978 (class 0 OID 16808)
-- Dependencies: 247
-- Data for Name: sso_providers; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.sso_providers (id, resource_id, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3967 (class 0 OID 16636)
-- Dependencies: 236
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, invited_at, confirmation_token, confirmation_sent_at, recovery_token, recovery_sent_at, email_change_token_new, email_change, email_change_sent_at, last_sign_in_at, raw_app_meta_data, raw_user_meta_data, is_super_admin, created_at, updated_at, phone, phone_confirmed_at, phone_change, phone_change_token, phone_change_sent_at, email_change_token_current, email_change_confirm_status, banned_until, reauthentication_token, reauthentication_sent_at, is_sso_user, deleted_at, is_anonymous) FROM stdin;
\.


--
-- TOC entry 3987 (class 0 OID 17031)
-- Dependencies: 256
-- Data for Name: alert_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alert_history (id, alert_rule_id, user_id, triggered_value, threshold_value, message, notification_channels, delivery_status, created_at, error_details) FROM stdin;
\.


--
-- TOC entry 3986 (class 0 OID 17015)
-- Dependencies: 255
-- Data for Name: alert_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alert_rules (id, user_id, name, description, alert_type, protocol_id, token_id, chain_id, condition, channels, throttle_minutes, enabled, created_at, updated_at, last_triggered_at, webhook_url) FROM stdin;
\.


--
-- TOC entry 3957 (class 0 OID 16457)
-- Dependencies: 223
-- Data for Name: alerts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alerts (id, user_id, type, message, priority, protocol_id, token_id, read, "timestamp", created_at) FROM stdin;
\.


--
-- TOC entry 3961 (class 0 OID 16502)
-- Dependencies: 227
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.api_keys (id, key, user_id, name, permissions, rate_limit, active, created_at, expires_at) FROM stdin;
50222674-e094-44d4-be64-1b432b8ea95d	defillama-dev-key-2024	\N	Development Key	{"read": true, "admin": false, "write": true}	10000	t	2025-10-14 06:10:20.617161+00	\N
\.


--
-- TOC entry 3959 (class 0 OID 16479)
-- Dependencies: 225
-- Data for Name: governance_proposals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.governance_proposals (id, protocol_id, proposal_id, title, description, status, votes_for, votes_against, end_time, "timestamp", created_at) FROM stdin;
\.


--
-- TOC entry 3958 (class 0 OID 16469)
-- Dependencies: 224
-- Data for Name: liquidations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.liquidations (id, protocol_id, user_address, collateral_token, debt_token, collateral_amount, debt_amount, liquidation_price, "timestamp", created_at) FROM stdin;
\.


--
-- TOC entry 3988 (class 0 OID 17058)
-- Dependencies: 257
-- Data for Name: notification_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notification_logs (id, alert_history_id, channel, status, recipient, error_message, retry_count, sent_at, created_at) FROM stdin;
\.


--
-- TOC entry 3985 (class 0 OID 16989)
-- Dependencies: 254
-- Data for Name: notification_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notification_templates (id, name, alert_type, channel, subject_template, body_template, variables, created_at, updated_at) FROM stdin;
3915ecb9-c7da-4eea-b99b-1cd55456878e	price_change_email	price_change	email	Alert: {{token_symbol}} Price {{direction}}	<h2>Price Alert: {{rule_name}}</h2>\n<p>{{message}}</p>\n<table>\n  <tr><td><strong>Token:</strong></td><td>{{token_symbol}}</td></tr>\n  <tr><td><strong>Current Price:</strong></td><td>${{triggered_value}}</td></tr>\n  <tr><td><strong>Threshold:</strong></td><td>${{threshold_value}}</td></tr>\n  <tr><td><strong>Time:</strong></td><td>{{timestamp}}</td></tr>\n</table>	{"message": "string", "direction": "string", "rule_name": "string", "timestamp": "string", "token_symbol": "string", "threshold_value": "number", "triggered_value": "number"}	2025-10-14 09:09:38.295476	2025-10-14 09:09:38.295476
155bc1f2-1de3-42e8-af67-2acd499158a5	tvl_change_email	tvl_change	email	Alert: {{protocol_name}} TVL {{direction}}	<h2>TVL Alert: {{rule_name}}</h2>\n<p>{{message}}</p>\n<table>\n  <tr><td><strong>Protocol:</strong></td><td>{{protocol_name}}</td></tr>\n  <tr><td><strong>Current TVL:</strong></td><td>${{triggered_value}}</td></tr>\n  <tr><td><strong>Threshold:</strong></td><td>${{threshold_value}}</td></tr>\n  <tr><td><strong>Time:</strong></td><td>{{timestamp}}</td></tr>\n</table>	{"message": "string", "direction": "string", "rule_name": "string", "timestamp": "string", "protocol_name": "string", "threshold_value": "number", "triggered_value": "number"}	2025-10-14 09:09:38.295476	2025-10-14 09:09:38.295476
c57ad8c6-00e2-4303-975c-3044ba7a8ae3	price_change_webhook	price_change	webhook	\N	{"alert_type": "price_change", "rule_name": "{{rule_name}}", "token_symbol": "{{token_symbol}}", "current_price": {{triggered_value}}, "threshold": {{threshold_value}}, "message": "{{message}}", "timestamp": {{timestamp}}}	{"message": "string", "rule_name": "string", "timestamp": "number", "token_symbol": "string", "threshold_value": "number", "triggered_value": "number"}	2025-10-14 09:09:38.295476	2025-10-14 09:09:38.295476
49a8323d-3ad3-4a01-9f3e-4a71b16cca0d	tvl_change_webhook	tvl_change	webhook	\N	{"alert_type": "tvl_change", "rule_name": "{{rule_name}}", "protocol_name": "{{protocol_name}}", "current_tvl": {{triggered_value}}, "threshold": {{threshold_value}}, "message": "{{message}}", "timestamp": {{timestamp}}}	{"message": "string", "rule_name": "string", "timestamp": "number", "protocol_name": "string", "threshold_value": "number", "triggered_value": "number"}	2025-10-14 09:09:38.295476	2025-10-14 09:09:38.295476
7ef41809-b3f3-41a4-8826-bc1bf1360a9d	price_change_push	price_change	push	{{token_symbol}} Price Alert	{{message}}	{"message": "string", "token_symbol": "string"}	2025-10-14 09:09:38.295476	2025-10-14 09:09:38.295476
47e6c362-be0f-4fdf-8389-252f17b6e12b	tvl_change_push	tvl_change	push	{{protocol_name}} TVL Alert	{{message}}	{"message": "string", "protocol_name": "string"}	2025-10-14 09:09:38.295476	2025-10-14 09:09:38.295476
\.


--
-- TOC entry 3954 (class 0 OID 16427)
-- Dependencies: 220
-- Data for Name: price_updates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.price_updates (id, token_id, price, change_24h, volume_24h, market_cap, "timestamp", created_at) FROM stdin;
673e5e61-a902-437e-856d-da4d900021ee	ethereum	2500.50000000	5.2000	15000000000.00	300000000000.00	2025-10-14 06:20:37.852621+00	2025-10-14 06:20:37.852621+00
\.


--
-- TOC entry 3992 (class 0 OID 17119)
-- Dependencies: 261
-- Data for Name: protocol_stats; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.protocol_stats (id, protocol_id, total_tvl, total_chains, avg_tvl_per_chain, max_tvl, min_tvl, last_updated, created_at) FROM stdin;
4c7161b7-50e3-495c-a862-7f81adba4965	uniswap	4300000000	3	1433333333	3500000000	300000000	2025-10-14 11:03:00.164482	2025-10-14 11:03:00.164482
fea7f52a-f970-4021-90d6-53fc2cab4b6c	aave	5800000000	2	2900000000	5000000000	800000000	2025-10-14 11:03:00.164482	2025-10-14 11:03:00.164482
1bfb74a7-14cd-498b-8cd3-4fe453d14414	curve	4200000000	1	4200000000	4200000000	4200000000	2025-10-14 11:03:00.164482	2025-10-14 11:03:00.164482
fa2ab59e-7f4a-4e1d-a401-5d51e050174c	makerdao	8000000000	1	8000000000	8000000000	8000000000	2025-10-14 11:03:00.164482	2025-10-14 11:03:00.164482
d9674967-306b-44ac-9216-42bdc6261162	compound	3000000000	1	3000000000	3000000000	3000000000	2025-10-14 11:03:00.164482	2025-10-14 11:03:00.164482
0b7f2791-b7c7-4cfa-b368-c87aa149b193	pancakeswap	2500000000	1	2500000000	2500000000	2500000000	2025-10-14 11:03:00.164482	2025-10-14 11:03:00.164482
fe104a09-b007-453a-9970-57bbda506094	lido	15000000000	1	15000000000	15000000000	15000000000	2025-10-14 11:03:00.164482	2025-10-14 11:03:00.164482
\.


--
-- TOC entry 3990 (class 0 OID 17088)
-- Dependencies: 259
-- Data for Name: protocol_tvl; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.protocol_tvl (id, protocol_id, chain, tvl, tvl_prev_day, tvl_prev_week, tvl_prev_month, change_1d, change_7d, change_30d, "timestamp", created_at) FROM stdin;
0b785ad4-13c6-42a7-81b9-c7ff82880a9b	uniswap	ethereum	3500000000	3400000000	\N	\N	2.94	\N	\N	2025-10-14 11:03:00.149316	2025-10-14 11:03:00.149316
e5382da4-6334-4009-a375-3f74b4261a36	uniswap	polygon	500000000	480000000	\N	\N	4.17	\N	\N	2025-10-14 11:03:00.149316	2025-10-14 11:03:00.149316
9c828a15-60aa-44d7-9781-426f82c94eab	uniswap	arbitrum	300000000	290000000	\N	\N	3.45	\N	\N	2025-10-14 11:03:00.149316	2025-10-14 11:03:00.149316
aae2c4c3-2619-4c4e-aa96-900225a12cf0	aave	ethereum	5000000000	4900000000	\N	\N	2.04	\N	\N	2025-10-14 11:03:00.149316	2025-10-14 11:03:00.149316
ef54174a-efdd-4935-9430-072ece9c2aa2	aave	polygon	800000000	780000000	\N	\N	2.56	\N	\N	2025-10-14 11:03:00.149316	2025-10-14 11:03:00.149316
53c1e0c9-58e0-4dea-ad05-60f73362432d	curve	ethereum	4200000000	4100000000	\N	\N	2.44	\N	\N	2025-10-14 11:03:00.149316	2025-10-14 11:03:00.149316
8502eaa0-4228-48b6-8046-8c2573baa8fb	makerdao	ethereum	8000000000	7900000000	\N	\N	1.27	\N	\N	2025-10-14 11:03:00.149316	2025-10-14 11:03:00.149316
f22529cb-89c1-4f6c-8a33-d4b47b7be632	compound	ethereum	3000000000	2950000000	\N	\N	1.69	\N	\N	2025-10-14 11:03:00.149316	2025-10-14 11:03:00.149316
859f82d2-b43e-43f0-ad0a-fe559c30cea2	pancakeswap	bsc	2500000000	2450000000	\N	\N	2.04	\N	\N	2025-10-14 11:03:00.149316	2025-10-14 11:03:00.149316
6c51d9ed-de46-461a-a20f-7b2e50e5e431	lido	ethereum	15000000000	14800000000	\N	\N	1.35	\N	\N	2025-10-14 11:03:00.149316	2025-10-14 11:03:00.149316
9a83ec96-ef4f-4332-94d0-9c36b3b737b8	uniswap	ethereum	3400000000	3300000000	\N	\N	3.03	\N	\N	2025-10-13 11:03:00.159398	2025-10-14 11:03:00.159398
ab7855ed-522b-438c-adb8-7622974c25c6	aave	ethereum	4900000000	4800000000	\N	\N	2.08	\N	\N	2025-10-13 11:03:00.159398	2025-10-14 11:03:00.159398
8f772147-a3a8-4d11-8cff-c0d282c3a9d0	curve	ethereum	4100000000	4000000000	\N	\N	2.50	\N	\N	2025-10-13 11:03:00.159398	2025-10-14 11:03:00.159398
44b4d62d-5b10-4007-b21e-44208549d5a8	makerdao	ethereum	7900000000	7800000000	\N	\N	1.28	\N	\N	2025-10-13 11:03:00.159398	2025-10-14 11:03:00.159398
e6ef1153-8db4-476b-8f24-21d67bbc428c	lido	ethereum	14800000000	14600000000	\N	\N	1.37	\N	\N	2025-10-13 11:03:00.159398	2025-10-14 11:03:00.159398
\.


--
-- TOC entry 3956 (class 0 OID 16447)
-- Dependencies: 222
-- Data for Name: protocol_updates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.protocol_updates (id, protocol_id, name, category, chains, tvl, "timestamp", created_at) FROM stdin;
\.


--
-- TOC entry 3989 (class 0 OID 17077)
-- Dependencies: 258
-- Data for Name: protocols; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.protocols (id, name, category, chains, description, website, logo_url, twitter, audit_links, created_at, updated_at) FROM stdin;
uniswap	Uniswap	DEX	{ethereum,polygon,arbitrum}	Leading decentralized exchange	https://uniswap.org	\N	\N	\N	2025-10-14 11:03:00.143553	2025-10-14 11:03:00.143553
aave	Aave	Lending	{ethereum,polygon,avalanche}	Decentralized lending protocol	https://aave.com	\N	\N	\N	2025-10-14 11:03:00.143553	2025-10-14 11:03:00.143553
curve	Curve Finance	DEX	{ethereum,polygon,arbitrum}	Stablecoin-focused DEX	https://curve.fi	\N	\N	\N	2025-10-14 11:03:00.143553	2025-10-14 11:03:00.143553
makerdao	MakerDAO	Lending	{ethereum}	Decentralized stablecoin protocol	https://makerdao.com	\N	\N	\N	2025-10-14 11:03:00.143553	2025-10-14 11:03:00.143553
compound	Compound	Lending	{ethereum}	Algorithmic money market	https://compound.finance	\N	\N	\N	2025-10-14 11:03:00.143553	2025-10-14 11:03:00.143553
pancakeswap	PancakeSwap	DEX	{bsc}	Leading BSC DEX	https://pancakeswap.finance	\N	\N	\N	2025-10-14 11:03:00.143553	2025-10-14 11:03:00.143553
sushiswap	SushiSwap	DEX	{ethereum,polygon,arbitrum}	Community-driven DEX	https://sushi.com	\N	\N	\N	2025-10-14 11:03:00.143553	2025-10-14 11:03:00.143553
yearn	Yearn Finance	Yield	{ethereum,fantom}	Yield aggregator	https://yearn.finance	\N	\N	\N	2025-10-14 11:03:00.143553	2025-10-14 11:03:00.143553
convex	Convex Finance	Yield	{ethereum}	Curve yield optimizer	https://convexfinance.com	\N	\N	\N	2025-10-14 11:03:00.143553	2025-10-14 11:03:00.143553
lido	Lido	Staking	{ethereum}	Liquid staking protocol	https://lido.fi	\N	\N	\N	2025-10-14 11:03:00.143553	2025-10-14 11:03:00.143553
\.


--
-- TOC entry 3993 (class 0 OID 17134)
-- Dependencies: 262
-- Data for Name: query_cache; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.query_cache (cache_key, query_hash, result, hit_count, expires_at, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3994 (class 0 OID 17146)
-- Dependencies: 263
-- Data for Name: query_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.query_logs (id, user_id, query_hash, query_params, execution_time_ms, result_count, cache_hit, error_message, created_at) FROM stdin;
\.


--
-- TOC entry 3963 (class 0 OID 16562)
-- Dependencies: 232
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.schema_migrations (version) FROM stdin;
00
20210710035447
20210722035447
20210730183235
20210909172000
20210927181326
20211122151130
20211124214934
20211202183645
20220114185221
20220114185340
20220224000811
20220323170000
20220429102000
20220531120530
20220614074223
20220811173540
20221003041349
20221003041400
20221011041400
20221020193600
20221021073300
20221021082433
20221027105023
20221114143122
20221114143410
20221125140132
20221208132122
20221215195500
20221215195800
20221215195900
20230116124310
20230116124412
20230131181311
20230322519590
20230402418590
20230411005111
20230508135423
20230523124323
20230818113222
20230914180801
20231027141322
20231114161723
20231117164230
20240115144230
20240214120130
20240306115329
20240314092811
20240427152123
20240612123726
\.


--
-- TOC entry 3960 (class 0 OID 16492)
-- Dependencies: 226
-- Data for Name: token_emissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.token_emissions (id, protocol_id, token_id, emission_rate, total_supply, circulating_supply, "timestamp", created_at) FROM stdin;
\.


--
-- TOC entry 3991 (class 0 OID 17106)
-- Dependencies: 260
-- Data for Name: token_prices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.token_prices (id, token_id, token_symbol, token_name, price, price_prev_day, price_prev_week, price_prev_month, change_1d, change_7d, change_30d, volume_24h, market_cap, "timestamp", created_at) FROM stdin;
dd8efa48-3b31-46ad-9abb-7970bdfe7cab	ethereum	ETH	Ethereum	2100.50	2050.00	\N	\N	2.46	\N	\N	15000000000	250000000000	2025-10-14 11:03:00.160121	2025-10-14 11:03:00.160121
f1d8cfe8-49c7-48f1-8cc2-148ff9593faf	bitcoin	BTC	Bitcoin	42000.00	41000.00	\N	\N	2.44	\N	\N	25000000000	800000000000	2025-10-14 11:03:00.160121	2025-10-14 11:03:00.160121
f9048ebd-95e5-4e79-a768-41ab7af3203b	binancecoin	BNB	BNB	310.00	305.00	\N	\N	1.64	\N	\N	1000000000	50000000000	2025-10-14 11:03:00.160121	2025-10-14 11:03:00.160121
7d7fec2d-9e67-4ea4-8263-69db446727f7	usd-coin	USDC	USD Coin	1.00	1.00	\N	\N	0.00	\N	\N	5000000000	25000000000	2025-10-14 11:03:00.160121	2025-10-14 11:03:00.160121
85b43884-de20-4062-8a74-129494b5bce1	tether	USDT	Tether	1.00	1.00	\N	\N	0.00	\N	\N	50000000000	90000000000	2025-10-14 11:03:00.160121	2025-10-14 11:03:00.160121
8b951c8f-33d6-4293-aa31-920eacf721bc	dai	DAI	Dai	1.00	1.00	\N	\N	0.00	\N	\N	500000000	5000000000	2025-10-14 11:03:00.160121	2025-10-14 11:03:00.160121
f0f3e59c-3e15-431e-8723-aee2d31b8084	uniswap	UNI	Uniswap	6.50	6.30	\N	\N	3.17	\N	\N	200000000	5000000000	2025-10-14 11:03:00.160121	2025-10-14 11:03:00.160121
ebd3dcea-534f-4892-82b1-2ab4ed91ded4	aave	AAVE	Aave	95.00	92.00	\N	\N	3.26	\N	\N	150000000	1500000000	2025-10-14 11:03:00.160121	2025-10-14 11:03:00.160121
6770f1ff-f21a-40de-8124-044039f31165	curve-dao-token	CRV	Curve DAO Token	0.85	0.82	\N	\N	3.66	\N	\N	100000000	500000000	2025-10-14 11:03:00.160121	2025-10-14 11:03:00.160121
a3cd2cca-fe9f-4f9b-afe0-3b161cc3adde	maker	MKR	Maker	1500.00	1480.00	\N	\N	1.35	\N	\N	50000000	1500000000	2025-10-14 11:03:00.160121	2025-10-14 11:03:00.160121
1220f519-631d-4d0f-b232-50459b7b1faf	ethereum	ETH	Ethereum	2080.00	2050.00	\N	\N	1.46	\N	\N	14500000000	248000000000	2025-10-14 10:03:00.163295	2025-10-14 11:03:00.163295
3c8f4961-7841-40d4-b69a-d48d6dadb406	bitcoin	BTC	Bitcoin	41500.00	41000.00	\N	\N	1.22	\N	\N	24500000000	795000000000	2025-10-14 10:03:00.163295	2025-10-14 11:03:00.163295
e0924955-301e-4fac-9133-3bac6e727265	uniswap	UNI	Uniswap	6.40	6.30	\N	\N	1.59	\N	\N	195000000	4900000000	2025-10-14 10:03:00.163295	2025-10-14 11:03:00.163295
\.


--
-- TOC entry 3955 (class 0 OID 16437)
-- Dependencies: 221
-- Data for Name: tvl_updates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tvl_updates (id, protocol_id, tvl, change_24h, chain, "timestamp", created_at) FROM stdin;
\.


--
-- TOC entry 3984 (class 0 OID 16974)
-- Dependencies: 253
-- Data for Name: user_devices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_devices (id, user_id, device_token, platform, device_name, app_version, os_version, enabled, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3962 (class 0 OID 16516)
-- Dependencies: 228
-- Data for Name: websocket_connections; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.websocket_connections (id, connection_id, user_id, api_key_id, connected_at, last_heartbeat, subscriptions, metadata) FROM stdin;
\.


--
-- TOC entry 3965 (class 0 OID 16577)
-- Dependencies: 234
-- Data for Name: buckets; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.buckets (id, name, owner, created_at, updated_at, public, avif_autodetection, file_size_limit, allowed_mime_types, owner_id) FROM stdin;
\.


--
-- TOC entry 3964 (class 0 OID 16569)
-- Dependencies: 233
-- Data for Name: migrations; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.migrations (id, name, hash, executed_at) FROM stdin;
0	create-migrations-table	e18db593bcde2aca2a408c4d1100f6abba2195df	2025-10-14 06:15:07.629044
1	initialmigration	6ab16121fbaa08bbd11b712d05f358f9b555d777	2025-10-14 06:15:07.861849
2	storage-schema	5c7968fd083fcea04050c1b7f6253c9771b99011	2025-10-14 06:15:07.878149
3	pathtoken-column	2cb1b0004b817b29d5b0a971af16bafeede4b70d	2025-10-14 06:15:08.040109
4	add-migrations-rls	427c5b63fe1c5937495d9c635c263ee7a5905058	2025-10-14 06:15:08.146961
5	add-size-functions	79e081a1455b63666c1294a440f8ad4b1e6a7f84	2025-10-14 06:15:08.169558
6	change-column-name-in-get-size	f93f62afdf6613ee5e7e815b30d02dc990201044	2025-10-14 06:15:08.219695
7	add-rls-to-buckets	e7e7f86adbc51049f341dfe8d30256c1abca17aa	2025-10-14 06:15:08.248425
8	add-public-to-buckets	fd670db39ed65f9d08b01db09d6202503ca2bab3	2025-10-14 06:15:08.260945
9	fix-search-function	3a0af29f42e35a4d101c259ed955b67e1bee6825	2025-10-14 06:15:08.290866
10	search-files-search-function	68dc14822daad0ffac3746a502234f486182ef6e	2025-10-14 06:15:08.300196
11	add-trigger-to-auto-update-updated_at-column	7425bdb14366d1739fa8a18c83100636d74dcaa2	2025-10-14 06:15:08.305499
12	add-automatic-avif-detection-flag	8e92e1266eb29518b6a4c5313ab8f29dd0d08df9	2025-10-14 06:15:08.316152
13	add-bucket-custom-limits	cce962054138135cd9a8c4bcd531598684b25e7d	2025-10-14 06:15:08.328286
14	use-bytes-for-max-size	941c41b346f9802b411f06f30e972ad4744dad27	2025-10-14 06:15:08.337314
15	add-can-insert-object-function	934146bc38ead475f4ef4b555c524ee5d66799e5	2025-10-14 06:15:08.655783
16	add-version	76debf38d3fd07dcfc747ca49096457d95b1221b	2025-10-14 06:15:08.662978
17	drop-owner-foreign-key	f1cbb288f1b7a4c1eb8c38504b80ae2a0153d101	2025-10-14 06:15:08.670569
18	add_owner_id_column_deprecate_owner	e7a511b379110b08e2f214be852c35414749fe66	2025-10-14 06:15:08.679761
19	alter-default-value-objects-id	02e5e22a78626187e00d173dc45f58fa66a4f043	2025-10-14 06:15:08.693696
\.


--
-- TOC entry 3966 (class 0 OID 16587)
-- Dependencies: 235
-- Data for Name: objects; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.objects (id, bucket_id, name, owner, created_at, updated_at, last_accessed_at, metadata, version, owner_id) FROM stdin;
\.


--
-- TOC entry 4072 (class 0 OID 0)
-- Dependencies: 237
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: auth; Owner: -
--

SELECT pg_catalog.setval('auth.refresh_tokens_id_seq', 1, false);


--
-- TOC entry 3677 (class 2606 OID 16803)
-- Name: mfa_amr_claims amr_id_pk; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT amr_id_pk PRIMARY KEY (id);


--
-- TOC entry 3653 (class 2606 OID 16672)
-- Name: audit_log_entries audit_log_entries_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.audit_log_entries
    ADD CONSTRAINT audit_log_entries_pkey PRIMARY KEY (id);


--
-- TOC entry 3699 (class 2606 OID 16909)
-- Name: flow_state flow_state_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.flow_state
    ADD CONSTRAINT flow_state_pkey PRIMARY KEY (id);


--
-- TOC entry 3659 (class 2606 OID 16927)
-- Name: identities identities_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_pkey PRIMARY KEY (id);


--
-- TOC entry 3661 (class 2606 OID 16937)
-- Name: identities identities_provider_id_provider_unique; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_provider_id_provider_unique UNIQUE (provider_id, provider);


--
-- TOC entry 3651 (class 2606 OID 16665)
-- Name: instances instances_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.instances
    ADD CONSTRAINT instances_pkey PRIMARY KEY (id);


--
-- TOC entry 3679 (class 2606 OID 16796)
-- Name: mfa_amr_claims mfa_amr_claims_session_id_authentication_method_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_authentication_method_pkey UNIQUE (session_id, authentication_method);


--
-- TOC entry 3675 (class 2606 OID 16784)
-- Name: mfa_challenges mfa_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_pkey PRIMARY KEY (id);


--
-- TOC entry 3670 (class 2606 OID 16771)
-- Name: mfa_factors mfa_factors_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_pkey PRIMARY KEY (id);


--
-- TOC entry 3703 (class 2606 OID 16962)
-- Name: one_time_tokens one_time_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_pkey PRIMARY KEY (id);


--
-- TOC entry 3645 (class 2606 OID 16655)
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- TOC entry 3648 (class 2606 OID 16713)
-- Name: refresh_tokens refresh_tokens_token_unique; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_token_unique UNIQUE (token);


--
-- TOC entry 3688 (class 2606 OID 16843)
-- Name: saml_providers saml_providers_entity_id_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_entity_id_key UNIQUE (entity_id);


--
-- TOC entry 3690 (class 2606 OID 16841)
-- Name: saml_providers saml_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_pkey PRIMARY KEY (id);


--
-- TOC entry 3695 (class 2606 OID 16857)
-- Name: saml_relay_states saml_relay_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_pkey PRIMARY KEY (id);


--
-- TOC entry 3656 (class 2606 OID 16678)
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- TOC entry 3665 (class 2606 OID 16734)
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- TOC entry 3685 (class 2606 OID 16824)
-- Name: sso_domains sso_domains_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_pkey PRIMARY KEY (id);


--
-- TOC entry 3681 (class 2606 OID 16815)
-- Name: sso_providers sso_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sso_providers
    ADD CONSTRAINT sso_providers_pkey PRIMARY KEY (id);


--
-- TOC entry 3638 (class 2606 OID 16897)
-- Name: users users_phone_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_phone_key UNIQUE (phone);


--
-- TOC entry 3640 (class 2606 OID 16642)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 3729 (class 2606 OID 17039)
-- Name: alert_history alert_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alert_history
    ADD CONSTRAINT alert_history_pkey PRIMARY KEY (id);


--
-- TOC entry 3719 (class 2606 OID 17030)
-- Name: alert_rules alert_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alert_rules
    ADD CONSTRAINT alert_rules_pkey PRIMARY KEY (id);


--
-- TOC entry 3593 (class 2606 OID 16468)
-- Name: alerts alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_pkey PRIMARY KEY (id);


--
-- TOC entry 3605 (class 2606 OID 16515)
-- Name: api_keys api_keys_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_key_key UNIQUE (key);


--
-- TOC entry 3607 (class 2606 OID 16513)
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- TOC entry 3599 (class 2606 OID 16491)
-- Name: governance_proposals governance_proposals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.governance_proposals
    ADD CONSTRAINT governance_proposals_pkey PRIMARY KEY (id);


--
-- TOC entry 3597 (class 2606 OID 16478)
-- Name: liquidations liquidations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.liquidations
    ADD CONSTRAINT liquidations_pkey PRIMARY KEY (id);


--
-- TOC entry 3737 (class 2606 OID 17068)
-- Name: notification_logs notification_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_logs
    ADD CONSTRAINT notification_logs_pkey PRIMARY KEY (id);


--
-- TOC entry 3715 (class 2606 OID 17001)
-- Name: notification_templates notification_templates_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_templates
    ADD CONSTRAINT notification_templates_name_key UNIQUE (name);


--
-- TOC entry 3717 (class 2606 OID 16999)
-- Name: notification_templates notification_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_templates
    ADD CONSTRAINT notification_templates_pkey PRIMARY KEY (id);


--
-- TOC entry 3585 (class 2606 OID 16436)
-- Name: price_updates price_updates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.price_updates
    ADD CONSTRAINT price_updates_pkey PRIMARY KEY (id);


--
-- TOC entry 3759 (class 2606 OID 17126)
-- Name: protocol_stats protocol_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.protocol_stats
    ADD CONSTRAINT protocol_stats_pkey PRIMARY KEY (id);


--
-- TOC entry 3748 (class 2606 OID 17095)
-- Name: protocol_tvl protocol_tvl_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.protocol_tvl
    ADD CONSTRAINT protocol_tvl_pkey PRIMARY KEY (id);


--
-- TOC entry 3591 (class 2606 OID 16456)
-- Name: protocol_updates protocol_updates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.protocol_updates
    ADD CONSTRAINT protocol_updates_pkey PRIMARY KEY (id);


--
-- TOC entry 3741 (class 2606 OID 17085)
-- Name: protocols protocols_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.protocols
    ADD CONSTRAINT protocols_pkey PRIMARY KEY (id);


--
-- TOC entry 3763 (class 2606 OID 17143)
-- Name: query_cache query_cache_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.query_cache
    ADD CONSTRAINT query_cache_pkey PRIMARY KEY (cache_key);


--
-- TOC entry 3768 (class 2606 OID 17154)
-- Name: query_logs query_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.query_logs
    ADD CONSTRAINT query_logs_pkey PRIMARY KEY (id);


--
-- TOC entry 3615 (class 2606 OID 16566)
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- TOC entry 3603 (class 2606 OID 16501)
-- Name: token_emissions token_emissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.token_emissions
    ADD CONSTRAINT token_emissions_pkey PRIMARY KEY (id);


--
-- TOC entry 3755 (class 2606 OID 17113)
-- Name: token_prices token_prices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.token_prices
    ADD CONSTRAINT token_prices_pkey PRIMARY KEY (id);


--
-- TOC entry 3588 (class 2606 OID 16446)
-- Name: tvl_updates tvl_updates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tvl_updates
    ADD CONSTRAINT tvl_updates_pkey PRIMARY KEY (id);


--
-- TOC entry 3711 (class 2606 OID 16985)
-- Name: user_devices user_devices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_devices
    ADD CONSTRAINT user_devices_pkey PRIMARY KEY (id);


--
-- TOC entry 3611 (class 2606 OID 16529)
-- Name: websocket_connections websocket_connections_connection_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.websocket_connections
    ADD CONSTRAINT websocket_connections_connection_id_key UNIQUE (connection_id);


--
-- TOC entry 3613 (class 2606 OID 16527)
-- Name: websocket_connections websocket_connections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.websocket_connections
    ADD CONSTRAINT websocket_connections_pkey PRIMARY KEY (id);


--
-- TOC entry 3623 (class 2606 OID 16585)
-- Name: buckets buckets_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.buckets
    ADD CONSTRAINT buckets_pkey PRIMARY KEY (id);


--
-- TOC entry 3618 (class 2606 OID 16576)
-- Name: migrations migrations_name_key; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_name_key UNIQUE (name);


--
-- TOC entry 3620 (class 2606 OID 16574)
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- TOC entry 3627 (class 2606 OID 16597)
-- Name: objects objects_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT objects_pkey PRIMARY KEY (id);


--
-- TOC entry 3654 (class 1259 OID 16673)
-- Name: audit_logs_instance_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX audit_logs_instance_id_idx ON auth.audit_log_entries USING btree (instance_id);


--
-- TOC entry 3628 (class 1259 OID 16723)
-- Name: confirmation_token_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX confirmation_token_idx ON auth.users USING btree (confirmation_token) WHERE ((confirmation_token)::text !~ '^[0-9 ]*$'::text);


--
-- TOC entry 3629 (class 1259 OID 16725)
-- Name: email_change_token_current_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX email_change_token_current_idx ON auth.users USING btree (email_change_token_current) WHERE ((email_change_token_current)::text !~ '^[0-9 ]*$'::text);


--
-- TOC entry 3630 (class 1259 OID 16726)
-- Name: email_change_token_new_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX email_change_token_new_idx ON auth.users USING btree (email_change_token_new) WHERE ((email_change_token_new)::text !~ '^[0-9 ]*$'::text);


--
-- TOC entry 3668 (class 1259 OID 16805)
-- Name: factor_id_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX factor_id_created_at_idx ON auth.mfa_factors USING btree (user_id, created_at);


--
-- TOC entry 3697 (class 1259 OID 16913)
-- Name: flow_state_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX flow_state_created_at_idx ON auth.flow_state USING btree (created_at DESC);


--
-- TOC entry 3657 (class 1259 OID 16893)
-- Name: identities_email_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX identities_email_idx ON auth.identities USING btree (email text_pattern_ops);


--
-- TOC entry 4073 (class 0 OID 0)
-- Dependencies: 3657
-- Name: INDEX identities_email_idx; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON INDEX auth.identities_email_idx IS 'Auth: Ensures indexed queries on the email column';


--
-- TOC entry 3662 (class 1259 OID 16720)
-- Name: identities_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX identities_user_id_idx ON auth.identities USING btree (user_id);


--
-- TOC entry 3700 (class 1259 OID 16910)
-- Name: idx_auth_code; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_auth_code ON auth.flow_state USING btree (auth_code);


--
-- TOC entry 3701 (class 1259 OID 16911)
-- Name: idx_user_id_auth_method; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_user_id_auth_method ON auth.flow_state USING btree (user_id, authentication_method);


--
-- TOC entry 3673 (class 1259 OID 16916)
-- Name: mfa_challenge_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX mfa_challenge_created_at_idx ON auth.mfa_challenges USING btree (created_at DESC);


--
-- TOC entry 3671 (class 1259 OID 16777)
-- Name: mfa_factors_user_friendly_name_unique; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX mfa_factors_user_friendly_name_unique ON auth.mfa_factors USING btree (friendly_name, user_id) WHERE (TRIM(BOTH FROM friendly_name) <> ''::text);


--
-- TOC entry 3672 (class 1259 OID 16922)
-- Name: mfa_factors_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX mfa_factors_user_id_idx ON auth.mfa_factors USING btree (user_id);


--
-- TOC entry 3704 (class 1259 OID 16969)
-- Name: one_time_tokens_relates_to_hash_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX one_time_tokens_relates_to_hash_idx ON auth.one_time_tokens USING hash (relates_to);


--
-- TOC entry 3705 (class 1259 OID 16968)
-- Name: one_time_tokens_token_hash_hash_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX one_time_tokens_token_hash_hash_idx ON auth.one_time_tokens USING hash (token_hash);


--
-- TOC entry 3706 (class 1259 OID 16970)
-- Name: one_time_tokens_user_id_token_type_key; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX one_time_tokens_user_id_token_type_key ON auth.one_time_tokens USING btree (user_id, token_type);


--
-- TOC entry 3631 (class 1259 OID 16727)
-- Name: reauthentication_token_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX reauthentication_token_idx ON auth.users USING btree (reauthentication_token) WHERE ((reauthentication_token)::text !~ '^[0-9 ]*$'::text);


--
-- TOC entry 3632 (class 1259 OID 16724)
-- Name: recovery_token_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX recovery_token_idx ON auth.users USING btree (recovery_token) WHERE ((recovery_token)::text !~ '^[0-9 ]*$'::text);


--
-- TOC entry 3641 (class 1259 OID 16656)
-- Name: refresh_tokens_instance_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_instance_id_idx ON auth.refresh_tokens USING btree (instance_id);


--
-- TOC entry 3642 (class 1259 OID 16657)
-- Name: refresh_tokens_instance_id_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_instance_id_user_id_idx ON auth.refresh_tokens USING btree (instance_id, user_id);


--
-- TOC entry 3643 (class 1259 OID 16719)
-- Name: refresh_tokens_parent_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_parent_idx ON auth.refresh_tokens USING btree (parent);


--
-- TOC entry 3646 (class 1259 OID 16807)
-- Name: refresh_tokens_session_id_revoked_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_session_id_revoked_idx ON auth.refresh_tokens USING btree (session_id, revoked);


--
-- TOC entry 3649 (class 1259 OID 16912)
-- Name: refresh_tokens_updated_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_updated_at_idx ON auth.refresh_tokens USING btree (updated_at DESC);


--
-- TOC entry 3691 (class 1259 OID 16849)
-- Name: saml_providers_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_providers_sso_provider_id_idx ON auth.saml_providers USING btree (sso_provider_id);


--
-- TOC entry 3692 (class 1259 OID 16914)
-- Name: saml_relay_states_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_relay_states_created_at_idx ON auth.saml_relay_states USING btree (created_at DESC);


--
-- TOC entry 3693 (class 1259 OID 16864)
-- Name: saml_relay_states_for_email_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_relay_states_for_email_idx ON auth.saml_relay_states USING btree (for_email);


--
-- TOC entry 3696 (class 1259 OID 16863)
-- Name: saml_relay_states_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_relay_states_sso_provider_id_idx ON auth.saml_relay_states USING btree (sso_provider_id);


--
-- TOC entry 3663 (class 1259 OID 16915)
-- Name: sessions_not_after_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sessions_not_after_idx ON auth.sessions USING btree (not_after DESC);


--
-- TOC entry 3666 (class 1259 OID 16806)
-- Name: sessions_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sessions_user_id_idx ON auth.sessions USING btree (user_id);


--
-- TOC entry 3683 (class 1259 OID 16831)
-- Name: sso_domains_domain_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX sso_domains_domain_idx ON auth.sso_domains USING btree (lower(domain));


--
-- TOC entry 3686 (class 1259 OID 16830)
-- Name: sso_domains_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sso_domains_sso_provider_id_idx ON auth.sso_domains USING btree (sso_provider_id);


--
-- TOC entry 3682 (class 1259 OID 16816)
-- Name: sso_providers_resource_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX sso_providers_resource_id_idx ON auth.sso_providers USING btree (lower(resource_id));


--
-- TOC entry 3667 (class 1259 OID 16804)
-- Name: user_id_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX user_id_created_at_idx ON auth.sessions USING btree (user_id, created_at);


--
-- TOC entry 3633 (class 1259 OID 16884)
-- Name: users_email_partial_key; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX users_email_partial_key ON auth.users USING btree (email) WHERE (is_sso_user = false);


--
-- TOC entry 4074 (class 0 OID 0)
-- Dependencies: 3633
-- Name: INDEX users_email_partial_key; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON INDEX auth.users_email_partial_key IS 'Auth: A partial unique index that applies only when is_sso_user is false';


--
-- TOC entry 3634 (class 1259 OID 16645)
-- Name: users_instance_id_email_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX users_instance_id_email_idx ON auth.users USING btree (instance_id, email);


--
-- TOC entry 3635 (class 1259 OID 16646)
-- Name: users_instance_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX users_instance_id_idx ON auth.users USING btree (instance_id);


--
-- TOC entry 3636 (class 1259 OID 16939)
-- Name: users_is_anonymous_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX users_is_anonymous_idx ON auth.users USING btree (is_anonymous);


--
-- TOC entry 3730 (class 1259 OID 17055)
-- Name: idx_alert_history_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alert_history_created ON public.alert_history USING btree (created_at DESC);


--
-- TOC entry 3731 (class 1259 OID 17053)
-- Name: idx_alert_history_rule; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alert_history_rule ON public.alert_history USING btree (alert_rule_id, created_at DESC);


--
-- TOC entry 3732 (class 1259 OID 17054)
-- Name: idx_alert_history_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alert_history_user ON public.alert_history USING btree (user_id, created_at DESC);


--
-- TOC entry 3720 (class 1259 OID 17049)
-- Name: idx_alert_rules_chain; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alert_rules_chain ON public.alert_rules USING btree (chain_id) WHERE (chain_id IS NOT NULL);


--
-- TOC entry 3721 (class 1259 OID 17052)
-- Name: idx_alert_rules_condition; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alert_rules_condition ON public.alert_rules USING gin (condition);


--
-- TOC entry 3722 (class 1259 OID 17050)
-- Name: idx_alert_rules_enabled; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alert_rules_enabled ON public.alert_rules USING btree (enabled) WHERE (enabled = true);


--
-- TOC entry 3723 (class 1259 OID 17051)
-- Name: idx_alert_rules_last_triggered; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alert_rules_last_triggered ON public.alert_rules USING btree (last_triggered_at) WHERE (last_triggered_at IS NOT NULL);


--
-- TOC entry 3724 (class 1259 OID 17047)
-- Name: idx_alert_rules_protocol; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alert_rules_protocol ON public.alert_rules USING btree (protocol_id) WHERE (protocol_id IS NOT NULL);


--
-- TOC entry 3725 (class 1259 OID 17048)
-- Name: idx_alert_rules_token; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alert_rules_token ON public.alert_rules USING btree (token_id) WHERE (token_id IS NOT NULL);


--
-- TOC entry 3726 (class 1259 OID 17046)
-- Name: idx_alert_rules_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alert_rules_type ON public.alert_rules USING btree (alert_type, enabled);


--
-- TOC entry 3727 (class 1259 OID 17045)
-- Name: idx_alert_rules_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alert_rules_user ON public.alert_rules USING btree (user_id, enabled);


--
-- TOC entry 3594 (class 1259 OID 16538)
-- Name: idx_alerts_user_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alerts_user_timestamp ON public.alerts USING btree (user_id, "timestamp" DESC);


--
-- TOC entry 3608 (class 1259 OID 16542)
-- Name: idx_api_keys_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_api_keys_key ON public.api_keys USING btree (key) WHERE (active = true);


--
-- TOC entry 3601 (class 1259 OID 16541)
-- Name: idx_emissions_protocol_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_emissions_protocol_timestamp ON public.token_emissions USING btree (protocol_id, "timestamp" DESC);


--
-- TOC entry 3600 (class 1259 OID 16540)
-- Name: idx_governance_protocol_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_governance_protocol_timestamp ON public.governance_proposals USING btree (protocol_id, "timestamp" DESC);


--
-- TOC entry 3595 (class 1259 OID 16539)
-- Name: idx_liquidations_protocol_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_liquidations_protocol_timestamp ON public.liquidations USING btree (protocol_id, "timestamp" DESC);


--
-- TOC entry 3733 (class 1259 OID 17074)
-- Name: idx_notification_logs_alert_history_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notification_logs_alert_history_id ON public.notification_logs USING btree (alert_history_id);


--
-- TOC entry 3734 (class 1259 OID 17076)
-- Name: idx_notification_logs_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notification_logs_created_at ON public.notification_logs USING btree (created_at);


--
-- TOC entry 3735 (class 1259 OID 17075)
-- Name: idx_notification_logs_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notification_logs_status ON public.notification_logs USING btree (status);


--
-- TOC entry 3712 (class 1259 OID 17002)
-- Name: idx_notification_templates_alert_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notification_templates_alert_type ON public.notification_templates USING btree (alert_type);


--
-- TOC entry 3713 (class 1259 OID 17003)
-- Name: idx_notification_templates_channel; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notification_templates_channel ON public.notification_templates USING btree (channel);


--
-- TOC entry 3583 (class 1259 OID 16535)
-- Name: idx_price_updates_token_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_price_updates_token_timestamp ON public.price_updates USING btree (token_id, "timestamp" DESC);


--
-- TOC entry 3756 (class 1259 OID 17132)
-- Name: idx_protocol_stats_protocol; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_protocol_stats_protocol ON public.protocol_stats USING btree (protocol_id);


--
-- TOC entry 3757 (class 1259 OID 17133)
-- Name: idx_protocol_stats_total_tvl; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_protocol_stats_total_tvl ON public.protocol_stats USING btree (total_tvl);


--
-- TOC entry 3742 (class 1259 OID 17102)
-- Name: idx_protocol_tvl_chain; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_protocol_tvl_chain ON public.protocol_tvl USING btree (chain);


--
-- TOC entry 3743 (class 1259 OID 17101)
-- Name: idx_protocol_tvl_protocol; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_protocol_tvl_protocol ON public.protocol_tvl USING btree (protocol_id);


--
-- TOC entry 3744 (class 1259 OID 17105)
-- Name: idx_protocol_tvl_protocol_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_protocol_tvl_protocol_timestamp ON public.protocol_tvl USING btree (protocol_id, "timestamp");


--
-- TOC entry 3745 (class 1259 OID 17103)
-- Name: idx_protocol_tvl_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_protocol_tvl_timestamp ON public.protocol_tvl USING btree ("timestamp");


--
-- TOC entry 3746 (class 1259 OID 17104)
-- Name: idx_protocol_tvl_tvl; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_protocol_tvl_tvl ON public.protocol_tvl USING btree (tvl);


--
-- TOC entry 3589 (class 1259 OID 16537)
-- Name: idx_protocol_updates_protocol_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_protocol_updates_protocol_timestamp ON public.protocol_updates USING btree (protocol_id, "timestamp" DESC);


--
-- TOC entry 3738 (class 1259 OID 17087)
-- Name: idx_protocols_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_protocols_category ON public.protocols USING btree (category);


--
-- TOC entry 3739 (class 1259 OID 17086)
-- Name: idx_protocols_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_protocols_name ON public.protocols USING btree (name);


--
-- TOC entry 3760 (class 1259 OID 17144)
-- Name: idx_query_cache_expires; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_query_cache_expires ON public.query_cache USING btree (expires_at);


--
-- TOC entry 3761 (class 1259 OID 17145)
-- Name: idx_query_cache_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_query_cache_hash ON public.query_cache USING btree (query_hash);


--
-- TOC entry 3764 (class 1259 OID 17156)
-- Name: idx_query_logs_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_query_logs_created ON public.query_logs USING btree (created_at);


--
-- TOC entry 3765 (class 1259 OID 17157)
-- Name: idx_query_logs_execution_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_query_logs_execution_time ON public.query_logs USING btree (execution_time_ms);


--
-- TOC entry 3766 (class 1259 OID 17155)
-- Name: idx_query_logs_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_query_logs_user ON public.query_logs USING btree (user_id);


--
-- TOC entry 3749 (class 1259 OID 17117)
-- Name: idx_token_prices_price; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_token_prices_price ON public.token_prices USING btree (price);


--
-- TOC entry 3750 (class 1259 OID 17115)
-- Name: idx_token_prices_symbol; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_token_prices_symbol ON public.token_prices USING btree (token_symbol);


--
-- TOC entry 3751 (class 1259 OID 17116)
-- Name: idx_token_prices_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_token_prices_timestamp ON public.token_prices USING btree ("timestamp");


--
-- TOC entry 3752 (class 1259 OID 17114)
-- Name: idx_token_prices_token; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_token_prices_token ON public.token_prices USING btree (token_id);


--
-- TOC entry 3753 (class 1259 OID 17118)
-- Name: idx_token_prices_token_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_token_prices_token_timestamp ON public.token_prices USING btree (token_id, "timestamp");


--
-- TOC entry 3586 (class 1259 OID 16536)
-- Name: idx_tvl_updates_protocol_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tvl_updates_protocol_timestamp ON public.tvl_updates USING btree (protocol_id, "timestamp" DESC);


--
-- TOC entry 3707 (class 1259 OID 16987)
-- Name: idx_user_devices_enabled; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_devices_enabled ON public.user_devices USING btree (enabled);


--
-- TOC entry 3708 (class 1259 OID 16988)
-- Name: idx_user_devices_token; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_user_devices_token ON public.user_devices USING btree (device_token);


--
-- TOC entry 3709 (class 1259 OID 16986)
-- Name: idx_user_devices_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_devices_user_id ON public.user_devices USING btree (user_id);


--
-- TOC entry 3609 (class 1259 OID 16543)
-- Name: idx_websocket_connections_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_websocket_connections_user ON public.websocket_connections USING btree (user_id);


--
-- TOC entry 3616 (class 1259 OID 16567)
-- Name: schema_migrations_version_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX schema_migrations_version_idx ON public.schema_migrations USING btree (version);


--
-- TOC entry 3621 (class 1259 OID 16586)
-- Name: bname; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX bname ON storage.buckets USING btree (name);


--
-- TOC entry 3624 (class 1259 OID 16603)
-- Name: bucketid_objname; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX bucketid_objname ON storage.objects USING btree (bucket_id, name);


--
-- TOC entry 3625 (class 1259 OID 16604)
-- Name: name_prefix_search; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX name_prefix_search ON storage.objects USING btree (name text_pattern_ops);


--
-- TOC entry 3787 (class 2620 OID 17057)
-- Name: alert_rules trigger_update_alert_rules_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trigger_update_alert_rules_updated_at BEFORE UPDATE ON public.alert_rules FOR EACH ROW EXECUTE FUNCTION public.update_alert_rules_updated_at();


--
-- TOC entry 3786 (class 2620 OID 16624)
-- Name: objects update_objects_updated_at; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER update_objects_updated_at BEFORE UPDATE ON storage.objects FOR EACH ROW EXECUTE FUNCTION storage.update_updated_at_column();


--
-- TOC entry 3772 (class 2606 OID 16707)
-- Name: identities identities_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- TOC entry 3776 (class 2606 OID 16797)
-- Name: mfa_amr_claims mfa_amr_claims_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- TOC entry 3775 (class 2606 OID 16785)
-- Name: mfa_challenges mfa_challenges_auth_factor_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_auth_factor_id_fkey FOREIGN KEY (factor_id) REFERENCES auth.mfa_factors(id) ON DELETE CASCADE;


--
-- TOC entry 3774 (class 2606 OID 16772)
-- Name: mfa_factors mfa_factors_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- TOC entry 3781 (class 2606 OID 16963)
-- Name: one_time_tokens one_time_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- TOC entry 3771 (class 2606 OID 16740)
-- Name: refresh_tokens refresh_tokens_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- TOC entry 3778 (class 2606 OID 16844)
-- Name: saml_providers saml_providers_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- TOC entry 3779 (class 2606 OID 16917)
-- Name: saml_relay_states saml_relay_states_flow_state_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_flow_state_id_fkey FOREIGN KEY (flow_state_id) REFERENCES auth.flow_state(id) ON DELETE CASCADE;


--
-- TOC entry 3780 (class 2606 OID 16858)
-- Name: saml_relay_states saml_relay_states_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- TOC entry 3773 (class 2606 OID 16735)
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- TOC entry 3777 (class 2606 OID 16825)
-- Name: sso_domains sso_domains_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- TOC entry 3782 (class 2606 OID 17040)
-- Name: alert_history alert_history_alert_rule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alert_history
    ADD CONSTRAINT alert_history_alert_rule_id_fkey FOREIGN KEY (alert_rule_id) REFERENCES public.alert_rules(id) ON DELETE CASCADE;


--
-- TOC entry 3783 (class 2606 OID 17069)
-- Name: notification_logs notification_logs_alert_history_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_logs
    ADD CONSTRAINT notification_logs_alert_history_id_fkey FOREIGN KEY (alert_history_id) REFERENCES public.alert_history(id) ON DELETE CASCADE;


--
-- TOC entry 3785 (class 2606 OID 17127)
-- Name: protocol_stats protocol_stats_protocol_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.protocol_stats
    ADD CONSTRAINT protocol_stats_protocol_id_fkey FOREIGN KEY (protocol_id) REFERENCES public.protocols(id) ON DELETE CASCADE;


--
-- TOC entry 3784 (class 2606 OID 17096)
-- Name: protocol_tvl protocol_tvl_protocol_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.protocol_tvl
    ADD CONSTRAINT protocol_tvl_protocol_id_fkey FOREIGN KEY (protocol_id) REFERENCES public.protocols(id) ON DELETE CASCADE;


--
-- TOC entry 3769 (class 2606 OID 16530)
-- Name: websocket_connections websocket_connections_api_key_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.websocket_connections
    ADD CONSTRAINT websocket_connections_api_key_id_fkey FOREIGN KEY (api_key_id) REFERENCES public.api_keys(id);


--
-- TOC entry 3770 (class 2606 OID 16598)
-- Name: objects objects_bucketId_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT "objects_bucketId_fkey" FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- TOC entry 3941 (class 0 OID 16666)
-- Dependencies: 240
-- Name: audit_log_entries; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.audit_log_entries ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 3952 (class 0 OID 16903)
-- Dependencies: 251
-- Name: flow_state; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.flow_state ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 3943 (class 0 OID 16700)
-- Dependencies: 242
-- Name: identities; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.identities ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 3940 (class 0 OID 16659)
-- Dependencies: 239
-- Name: instances; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.instances ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 3947 (class 0 OID 16790)
-- Dependencies: 246
-- Name: mfa_amr_claims; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.mfa_amr_claims ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 3946 (class 0 OID 16778)
-- Dependencies: 245
-- Name: mfa_challenges; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.mfa_challenges ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 3945 (class 0 OID 16765)
-- Dependencies: 244
-- Name: mfa_factors; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.mfa_factors ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 3953 (class 0 OID 16953)
-- Dependencies: 252
-- Name: one_time_tokens; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.one_time_tokens ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 3939 (class 0 OID 16648)
-- Dependencies: 238
-- Name: refresh_tokens; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.refresh_tokens ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 3950 (class 0 OID 16832)
-- Dependencies: 249
-- Name: saml_providers; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.saml_providers ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 3951 (class 0 OID 16850)
-- Dependencies: 250
-- Name: saml_relay_states; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.saml_relay_states ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 3942 (class 0 OID 16674)
-- Dependencies: 241
-- Name: schema_migrations; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.schema_migrations ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 3944 (class 0 OID 16730)
-- Dependencies: 243
-- Name: sessions; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.sessions ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 3949 (class 0 OID 16817)
-- Dependencies: 248
-- Name: sso_domains; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.sso_domains ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 3948 (class 0 OID 16808)
-- Dependencies: 247
-- Name: sso_providers; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.sso_providers ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 3938 (class 0 OID 16636)
-- Dependencies: 236
-- Name: users; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.users ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 3936 (class 0 OID 16577)
-- Dependencies: 234
-- Name: buckets; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.buckets ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 3935 (class 0 OID 16569)
-- Dependencies: 233
-- Name: migrations; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.migrations ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 3937 (class 0 OID 16587)
-- Dependencies: 235
-- Name: objects; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

-- Completed on 2025-10-14 16:56:22 UTC

--
-- PostgreSQL database dump complete
--

\unrestrict FrDDK1lS0DoI2Lgbv0gOYU7JF9Zftb1mZOTCQAV3mhd9xh80qkybjKt8VDLbwsn

